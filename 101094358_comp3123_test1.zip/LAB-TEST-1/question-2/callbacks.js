
const resolvedPromise = () => new Promise((resolve, reject) => {
    setTimeout(() => {
        let success = {'message': 'delayed success!'}
        resolve(success);
    }, 500)
});


const rejectedPromise = () => new Promise((resolve, reject) => {
    setTimeout(() => {
        let e = {'error': 'delayed exception!'}
        reject(e);
    }, 500);
});


resolvedPromise().then(success => {
    console.log(success)
})
rejectedPromise().catch(error =>  { 
    console.log( error);})