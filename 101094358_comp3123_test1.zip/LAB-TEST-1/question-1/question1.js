const mixedArray = ['PIZZA', 10, true, 25, false, 'Wings']

function lowerCaseWords(array){

    let result = new Promise(function(resolve, reject){
        let str = array.filter(n => {
            if(typeof n === 'string'){
                return n
            }
        })
        let new_arr = str.map(i => i.toLowerCase())
        if( Object.keys(new_arr).length != 0){
            resolve(new_arr)
        }else{
            reject("***errors***")
        }

    })

    result.then(success => {
        console.log(success)
      }, error =>  console.log(error) )
      
}
lowerCaseWords(mixedArray)