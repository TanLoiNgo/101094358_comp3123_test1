const fs = require('fs');


const dirPath = './logs';

removeDir = function(dir) {
    try {
        if (!fs.existsSync(dir)){
            console.log('There are no logs directory to remove')
        }
        var files = fs.readdirSync(dir); 
        if (files.length > 0){
            for (var i = 0; i < files.length; i++) {
                var filePath = dir + '/' + files[i];
                if (fs.statSync(filePath).isFile()){
                  fs.unlinkSync(filePath);
                  console.log('delete files...' + files[i])
                }
                else
                  rmDir(filePath);
              }
          }else{
              console.log('There are no log files to delete')
          }
            
          fs.rmdirSync(dir);
    }
    catch(e) { return; }
    
    };
removeDir(dirPath)