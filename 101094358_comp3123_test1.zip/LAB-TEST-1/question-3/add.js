var fs = require('fs');
var dirpath = `${__dirname}/logs`;

createLogFiles = function(dir) {
    if (!fs.existsSync(dir)){
        fs.mkdirSync(dir)
    }
    process.chdir(dir)
    for(i = 0; i < 10; i++){
        fs.writeFile('log'+[i]+'.txt', 'I am working on Node.JS File system', function (err) {
            if (err) throw err;
        });
    }    
    
    fs.readdir(dir, (err, files) => {
        files.forEach(file => {
        console.log(file);
        });
    });
};
createLogFiles(dirpath)


 